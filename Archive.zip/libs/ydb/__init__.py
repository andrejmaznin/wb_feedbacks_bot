from .utils import get_or_generate_id, prepare_and_execute_query
