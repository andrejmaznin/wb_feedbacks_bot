PYTHON_TO_YDB_TYPES = {
    str: 'String',
    dict: 'JsonDocument',
    list: 'JsonDocument',
    bool: 'Bool'
}
