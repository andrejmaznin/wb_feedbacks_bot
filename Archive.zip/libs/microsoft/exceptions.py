class MSAuthException(BaseException):
    pass
