BASE_DIR_PARENT_REFERENCE = {
    'driveId': '3a822afd6b06b1f4',
    'driveType': 'personal',
    'id': '3A822AFD6B06B1F4!360',
    'name': 'wb-reviews'
}
