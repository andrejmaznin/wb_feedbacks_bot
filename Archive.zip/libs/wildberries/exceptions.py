class WBAuthException(BaseException):
    pass
