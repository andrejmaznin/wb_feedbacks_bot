from .handlers.root import handler as handle_cabinets_command
from .handlers.add import handler as handle_cabinets_add_command
from .handlers.remove import handler as handle_cabinets_remove_command
