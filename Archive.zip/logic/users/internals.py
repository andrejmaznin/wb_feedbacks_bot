import uuid
from typing import Optional

from connections import get_session_pool, bot
from libs.ydb import get_or_generate_id
from logic.users.messages import format_list_of_users
from logic.users.schemas import UserSchema
from markups.root import get_root_reply_markup


def add_user(client_id: str, data: str):
    pool = get_session_pool()

    data = data.lstrip('@')
    user_id = get_or_generate_id(
        f'SELECT id FROM users '
        f'WHERE (data="{data}" OR username="{data}" OR telegram_id="{data}") '
        f'AND client_id="{client_id}"'
    )

    with pool.checkout() as session:
        session.transaction().execute(
            f'UPSERT INTO users (id, client_id, pending, data) '
            f'VALUES ("{user_id}", "{client_id}", True, "{data}")',
            commit_tx=True
        )


def activate_invited_user(
    client_id: str,
    user_id: str,
    telegram_id: int,
    username: Optional[str] = None
):
    pool = get_session_pool()

    with pool.checkout() as session:
        if username is not None:
            username = username.lstrip('@')
            query = f'UPDATE users SET pending=False, data=NULL, owner=False, ' \
                    f'telegram_id="{telegram_id}", username="{username}" ' \
                    f'WHERE id="{user_id}" AND client_id="{client_id}"'
        else:
            query = f'UPDATE users SET pending=False, data=NULL, owner=False' \
                    f'telegram_id="{telegram_id}" ' \
                    f'WHERE id="{user_id}" AND client_id="{client_id}"'

        session.transaction().execute(query, commit_tx=True)

    bot.send_message(
        chat_id=telegram_id,
        text='Добро пожаловать!\nВы были приглашены другим участником',
        reply_markup=get_root_reply_markup(client_id)
    )


def delete_user(
    client_id: str,
    data: str,
    telegram_id: int,
    username: Optional[str] = None
) -> bool:
    pool = get_session_pool()

    if data == str(telegram_id) or data == username:
        return False

    with pool.checkout() as session:
        result = session.transaction().execute(
            f'SELECT id FROM users '
            f'WHERE client_id="{client_id}" AND (telegram_id="{data}" OR username="{data}" OR data="{data}")',
            commit_tx=True
        )
        if not result[0].rows:
            return False

        user_id = result[0].rows[0].id.decode('utf-8')
        session.transaction().execute(
            f'DELETE FROM users WHERE id="{user_id}"',
            commit_tx=True
        )

    return True


def get_user(
    telegram_id: int,
    username: Optional[str] = None
) -> Optional[UserSchema]:
    pool = get_session_pool()

    with pool.checkout() as session:
        if username is not None:
            result = session.transaction().execute(
                f'SELECT * FROM users '
                f'WHERE telegram_id="{telegram_id}" AND username="{username}" AND pending=False',
                commit_tx=True
            )
        else:
            result = session.transaction().execute(
                f'SELECT * FROM users '
                f'WHERE telegram_id="{telegram_id}" AND pending=False',
                commit_tx=True
            )

        if not result[0].rows:
            if username is not None:
                result = session.transaction().execute(
                    f'SELECT * FROM users '
                    f'WHERE (data="{telegram_id}" or data="{username}") AND pending=True',
                    commit_tx=True
                )
            else:
                result = session.transaction().execute(
                    f'SELECT * FROM users '
                    f'WHERE data="{telegram_id}" AND pending=True',
                    commit_tx=True
                )

        if not result[0].rows:
            return None

    return UserSchema(
        id=result[0].rows[0].id.decode('utf-8'),
        client_id=result[0].rows[0].client_id.decode('utf-8'),
        username=username,
        telegram_id=telegram_id,
        data=result[0].rows[0].data.decode('utf-8') if result[0].rows[0].data is not None else None,
        owner=result[0].rows[0].owner,
        pending=result[0].rows[0].pending
    )


def get_formatted_list_of_users(client_id: str) -> str:
    users = UserSchema.get_for_client(client_id=client_id)
    return format_list_of_users(users=users)


def create_client_and_user(
    telegram_id: int,
    username: Optional[str] = None
) -> UserSchema:
    pool = get_session_pool()

    client_id = str(uuid.uuid4())
    user_id = str(uuid.uuid4())

    with pool.checkout() as session:
        session.transaction().execute(
            f'UPSERT INTO clients (id) VALUES ("{client_id}")',
            commit_tx=True
        )
        if username is not None:
            session.transaction().execute(
                f'UPSERT INTO users (id, client_id, telegram_id, username, pending) VALUES '
                f'("{user_id}", "{client_id}", "{telegram_id}", "{username}", False)',
                commit_tx=True
            )
        else:
            session.transaction().execute(
                f'UPSERT INTO users (id, client_id, telegram_id, pending) VALUES '
                f'("{user_id}", "{client_id}", "{telegram_id}", False)',
                commit_tx=True
            )

    return UserSchema(
        id=user_id,
        client_id=client_id,
        telegram_id=telegram_id,
        username=username,
        pending=False
    )


def authorize_user(
    telegram_id: int,
    username: Optional[str] = None
) -> Optional[UserSchema]:
    if user := get_user(telegram_id=telegram_id, username=username):
        print(f'User: {user}')
        if user.pending is True:
            activate_invited_user(
                user_id=user.id,
                client_id=user.client_id,
                telegram_id=telegram_id,
                username=username
            )
        return user
    return None
