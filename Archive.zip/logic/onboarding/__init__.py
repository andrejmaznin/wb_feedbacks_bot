from .handlers import handler as handle_user_onboarding_command
