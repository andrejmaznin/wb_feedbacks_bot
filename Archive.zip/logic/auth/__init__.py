from .handlers.update import handler as handle_update_auth_data_command
