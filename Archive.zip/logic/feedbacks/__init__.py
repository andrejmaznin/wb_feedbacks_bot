from .handlers.add.barcode import handler as handle_feedbacks_add_barcode_command
from .handlers.add.text import handler as handle_feedbacks_add_text_command
from .handlers.default.add import handler as handle_feedbacks_default_add_command
from .handlers.default.remove import handler as handle_feedbacks_default_remove_command
from .handlers.default.root import handler as handle_feedbacks_default_command
from .handlers.exclude import handler as handle_feedbacks_exclude_command
from .handlers.file import handler as handle_feedbacks_file_import_command
from .handlers.root import handler as handle_feedbacks_command
