from .main import _settings as settings
