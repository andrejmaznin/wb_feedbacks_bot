CREATE TABLE 'promocodes'
(
    'code' String,
    PRIMARY KEY ('code')
);
