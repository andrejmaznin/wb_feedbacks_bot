CREATE TABLE 'purchases'
(
    'id' String,
    'client_id' String,
    'date' Date,
    'execute' Bool,
    PRIMARY KEY ('id')
);
