CREATE TABLE 'payments'
(
    'id' String,
    'client_id' String,
    'telegram_id' String,
    PRIMARY KEY ('id')
);
