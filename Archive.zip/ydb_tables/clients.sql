CREATE TABLE 'clients'
(
    'id' String,
    'cabinets_cap' Integer,
    PRIMARY KEY ('id')
);