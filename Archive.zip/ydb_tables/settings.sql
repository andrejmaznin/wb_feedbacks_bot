CREATE TABLE 'settings'
(
    'id' String,
    'client_id' String,
    'complain' Bool,
    PRIMARY KEY ('id')
);
