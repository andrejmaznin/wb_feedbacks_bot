CREATE TABLE 'exclude_feedbacks'
(
    'barcode' String,
    'client_id' String,
    PRIMARY KEY ('barcode', 'client_id')
);
